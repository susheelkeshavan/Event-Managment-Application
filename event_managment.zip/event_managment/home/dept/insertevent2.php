<?php
session_start();
?>
<?php

$aid = $_POST["aid"];
$rid = $_POST["rid"];
$cin = $_POST["cin"];
$cout = $_POST["cout"];


$u=0;




/* connecting*/
$link = mysqli_connect("localhost", "root", "", "event_managment");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
 $sql = "INSERT INTO attendance_table (aid, rid,  cin , cout) VALUES ( ('$aid'),('$rid'), ('$cin'),('$cout'))";
 if(mysqli_query($link, $sql)){
    echo "Attendance Registration successfully.";

	
	
$onn = mysqli_connect("localhost","root","","event_managment");
	if ($onn-> connect_error)
	{
	die("connection failed:".$onn-> connect_error);
	}


		
	
	
	
	
	
	
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}

  
 
 
// Close connection
mysqli_close($link);



?>
