<?php
session_start();
?>
<?php

$rid = $_POST["rid"];
$eid = $_POST["eid"];
$uname = $_POST["uname"];
$uemail = $_POST["uemail"];


$u=0;




/* connecting*/
$link = mysqli_connect("localhost", "root", "", "event_managment");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
 $sql = "INSERT INTO registration_table (rid	, eid,  uname , uemail	) VALUES ( ('$rid'),('$eid'), ('$uname'),('$uemail'))";
 if(mysqli_query($link, $sql)){
    echo " Registration successfully.";

	
	
$onn = mysqli_connect("localhost","root","","event_managment");
	if ($onn-> connect_error)
	{
	die("connection failed:".$onn-> connect_error);
	}


		
	
	
	
	
	
	
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}

  
 
 
// Close connection
mysqli_close($link);



?>
