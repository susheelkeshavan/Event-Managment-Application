<?php
session_start();
?>
<?php

$ename = $_POST["ename"];
$eid = $_POST["eid"];
$edesc = $_POST["edesc"];
$eloc = $_POST["eloc"];
$edate = $_POST["edate"];


$u=0;




/* connecting*/
$link = mysqli_connect("localhost", "root", "", "event_managment");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
 $sql = "INSERT INTO events_table (ename	, eid,  edate , eloc,edesc	) VALUES ( ('$ename'),('$eid'), ('$edate'), ('$eloc'),('$edesc'))";
 if(mysqli_query($link, $sql)){
    echo "Event Registration successfully.";

	
	
$onn = mysqli_connect("localhost","root","","event_managment");
	if ($onn-> connect_error)
	{
	die("connection failed:".$onn-> connect_error);
	}


		
	
	
	
	
	
	
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}

  
 
 
// Close connection
mysqli_close($link);



?>
