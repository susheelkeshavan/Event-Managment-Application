<?php
session_start();
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title>PESITM</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">


</head>


<body>
<div class="body">

	<div class="container-contact10">
		<div class="wrap-contact10">

<form action="" method="POST">
<center>
<h1 class="col"}>Remove an event</h1><br><br>
<h5>Enter Event ID</h5>
<div>
			<input type="text" name="USN" placeholder=" Enter Event ID" required ><br><br>
	</div>	<br><br>
	<input type="submit" class="button" value="delete" name="search">
	</center>
<?php

	include ("connection.php");
	if ($conn-> connect_error)
	{
	die("connection failed:".$conn-> connect_error);
	}
	
	if(isset($_POST['search']))
	{
		$eid=$_POST['USN'];
			//$tdid = $_SESSION["deptid"];
		
		$sql = "delete from eventt where eid=$eid";
		//$sql = "delete from eventt where eid='". $_GET["eid"]. "'";
		$result = $conn-> query($sql);
		echo "Record updated";
		header("Location:depthome.html");
	
	}
	?>
	</form>
</div>

</body>
</html>