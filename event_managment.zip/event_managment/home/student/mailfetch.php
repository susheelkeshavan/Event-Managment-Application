<?php
// Start the session
session_start();

$sid = $_SESSION["studid"];
$seid = $_SESSION["eide"];

$conn = mysqli_connect("localhost","root","","event_managment");
	if ($conn-> connect_error)
	{
	die("connection failed:".$conn-> connect_error);
	}


$str = "SELECT name,email FROM student WHERE usn='$sid'";

	$result = $conn-> query($str) ;
;
	while ($row = $result-> fetch_assoc() )
		{
$sname = $row['name'];
$semail = $row['email'];
$sub = "Utsav Application Pass";
$msg ="Dear $sname  welcomes you to pesitm \n We Thank you for showing your intrest and applyong for the event id $seid \n We kindly request you to bring your college ID during the event \n Make yor cash payment at the account department showing this Email and Your valid ID and collect your passes.\n Thanks and Regards";
echo "$sname ------------";
echo "$semail------------";
echo "$sub------------";
echo "$msg------------";
		}


date_default_timezone_set('Etc/UTC');

require 'PHPMailer/PHPMailerAutoload.php';


$mail = new PHPMailer;

$mail->isSMTP();

$mail->SMTPDebug = 2;


$mail->Debugoutput = 'html';

$mail->Host = 'smtp.gmail.com';

$mail->Port = 587;


$mail->SMTPSecure = 'tls';

$mail->SMTPAuth = true;


$mail->Username = "mr.technofreak420@gmail.com";


$mail->Password = "istandalone";


$mail->setFrom('mr.technofreak420@gmail.com', 'BMSCE UTSAV');

$mail->addReplyTo($semail, $sname);


$mail->addAddress($semail, $sub);


$mail->Subject = $sub;

$mail->msgHTML('<!DOCTYPE html <html><body>'.$msg.'</body></html>');

$mail->AltBody = $sub;

if (!$mail->send()) {
    echo "Mailer Error: " . $mail->ErrorInfo;
} else {
    echo "Message sent!";
    //Section 2: IMAP
    //Uncomment these to save your message in the 'Sent Mail' folder.
    #if (save_mail($mail)) {
    #    echo "Message saved!";
    #}
}


function save_mail($mail) {
   
    $path = "{imap.gmail.com:993/imap/ssl}[Gmail]/Sent Mail";

   
    $imapStream = imap_open($path, $mail->Username, $mail->Password);

    $result = imap_append($imapStream, $path, $mail->getSentMIMEMessage());
    imap_close($imapStream);

    return $result;
}
?>










