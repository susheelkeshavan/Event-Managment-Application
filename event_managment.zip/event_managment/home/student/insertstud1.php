<?php
// Start the session
session_start();
?>

<?php

$name = $_POST["name"];
$email = $_POST["email"];
$pass = $_POST["pass"];



/* connecting*/
$link = mysqli_connect("localhost", "root", "", "event_managment");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Attempt insert query execution
$sql = "INSERT INTO admin (name,email,pass) VALUES (('$name'),('$email'), ('$pass'))";
if(mysqli_query($link, $sql))
{
    echo "Records inserted successfully.";
	  
}
else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}

 
 
// Close connection
mysqli_close($link);



?>
