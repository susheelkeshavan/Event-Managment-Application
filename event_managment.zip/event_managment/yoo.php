
<html>
<head>

</head>
<body>
giii
<button onclick='phpadd()'>add</button>
</body>

<?php
function phpadd(){
 echo"hiii";

}
?>
</head>

</html>






